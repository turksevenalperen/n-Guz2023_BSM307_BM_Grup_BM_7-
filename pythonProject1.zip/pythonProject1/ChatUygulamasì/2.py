# client.py
from socket import *
from threading import *
from tkinter import *
from tkinter import messagebox
import csv

def authenticate_user(username, password):
    return True

def add_user_to_csv(username, password):
    file_path = "KullanıcıBilgileri.csv"
    with open(file_path, mode='a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([username, password])

def login():
    global login_window
    username = usernameEntry.get()
    password = passwordEntry.get()

    if authenticate_user(username, password):
        login_window.destroy()  # Giriş penceresini kapat

        add_user_to_csv(username, password)  # Kullanıcıyı CSV dosyasına ekle

        def recvMessage():
            while True:
                try:
                    serverMessage = client.recv(1024).decode('utf8')
                    messages.insert(END, '\n' + serverMessage)
                except OSError:  # Soket kapandığında çıkış yap
                    break

        client = socket(AF_INET, SOCK_STREAM)
        ip = ('127.0.0.1'
              ''
              '')
        port = 55555
        client.connect((ip, port))

        chat_window = Tk()
        chat_window.title('Sohbet')

        messages = Text(chat_window, width=50)
        messages.grid(row=0, column=0, padx=10, pady=10)

        yourMessage = Entry(chat_window, width=50)
        yourMessage.insert(0, username)
        yourMessage.grid(row=1, column=0, padx=10, pady=10)
        yourMessage.focus()
        yourMessage.selection_range(0, END)

        def sendMessage(event=None):
            clientMessage = yourMessage.get()
            messages.insert(END, '\n' + 'Sen: ' + clientMessage)
            client.send(clientMessage.encode('utf8'))
            yourMessage.delete(0, END)

        def on_enter_pressed(event):
            sendMessage()

        chat_window.bind('<Return>', on_enter_pressed)

        bmessageGonder = Button(chat_window, text='Gönder', width=20, command=sendMessage)
        bmessageGonder.grid(row=2, column=0, padx=10, pady=10)

        recvThread = Thread(target=recvMessage)
        recvThread.daemon = True
        recvThread.start()

        chat_window.protocol("WM_DELETE_WINDOW", lambda: client.close())
        chat_window.mainloop()

    else:
        messagebox.showerror("Hata", "Kullanıcı adı veya şifre hatalı!")

# Giriş penceresini oluştur
login_window = Tk()
login_window.title("Giris Ekranı")
login_window.geometry("450x250")

userLabel = Label(login_window, width=20, height=3, text="Kullanıcı Adı :", font="Times 10 bold")
userLabel.place(x=5, y=26)

passwordLabel = Label(login_window, width=20, height=3, text="Sifre :", font="Times 10 bold")
passwordLabel.place(x=5, y=66)

usernameEntry = Entry(login_window, width=15, font="bold")
usernameEntry.place(x=150, y=26)

passwordEntry = Entry(login_window, width=15, font="bold", show="*")
passwordEntry.place(x=150, y=66)

controlButton = Button(login_window, text="GİRİS", width=30, font="bold", command=login)
controlButton.place(x=10, y=150)

login_window.mainloop()
