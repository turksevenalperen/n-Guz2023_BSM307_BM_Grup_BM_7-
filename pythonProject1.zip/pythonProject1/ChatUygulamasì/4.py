
import csv

file_path = "KullanıcıBilgileri.csv"

# CSV dosyasını okuma
with open(file_path, mode='r') as file:
    reader = csv.reader(file)
    for row in reader:
        print(row)  # Her bir satırı yazdırabilirsiniz
