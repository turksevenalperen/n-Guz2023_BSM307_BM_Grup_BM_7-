# login.py
import tkinter as tk
from tkinter import messagebox, Text, Entry, Button
from socket import *
from threading import Thread
import csv

def login():
    username = usernameEntry.get()
    password = passwordEntry.get()

    if authenticate_user(username, password):
        login_window.destroy()  # Giriş penceresini kapat

        chat_window = tk.Tk()
        chat_window.title('Sohbet')

        client = socket(AF_INET, SOCK_STREAM)
        ip = '127.0.0.2'
        port = 55555
        client.connect((ip, port))

        messages = Text(chat_window, width=50)
        messages.grid(row=0, column=0, padx=10, pady=10)

        yourMessage = Entry(chat_window, width=50)
        yourMessage.insert(0, username)
        yourMessage.grid(row=1, column=0, padx=10, pady=10)
        yourMessage.focus()
        yourMessage.selection_range(0, tk.END)

        def sendMessage(event=None):
            clientMessage = yourMessage.get()
            messages.insert(tk.END, '\n' + 'Sen: ' + clientMessage)
            client.send(clientMessage.encode('utf8'))
            yourMessage.delete(0, tk.END)

        def on_enter_pressed(event):
            sendMessage()

        chat_window.bind('<Return>', on_enter_pressed)

        bmessageGonder = Button(chat_window, text='Gönder', width=20, command=sendMessage)
        bmessageGonder.grid(row=2, column=0, padx=10, pady=10)

        def recvMessage():
            while True:
                serverMessage = client.recv(1024).decode('utf8')
                messages.insert(tk.END, '\n' + serverMessage)

        recvThread = Thread(target=recvMessage)
        recvThread.daemon = True
        recvThread.start()

        chat_window.mainloop()
    else:
        messagebox.showerror("Hata", "Kullanıcı adı veya şifre hatalı!")

def authenticate_user(username, password):
    file_path = "KullanıcıBilgileri.csv"
    with open(file_path, mode='r') as file:
        reader = csv.reader(file)
        for row in reader:
            if row[0] == username and row[1] == password:
                return True
    return False

login_window = tk.Tk()
login_window.title("hw-education")
login_window.geometry("450x250")

userLabel = tk.Label(login_window, width=20, height=3, text="USERNAME :", font="Times 10 bold")
userLabel.place(x=5, y=26)

passwordLabel = tk.Label(login_window, width=20, height=3, text="PASSWORD :", font="Times 10 bold")
passwordLabel.place(x=5, y=66)

usernameEntry = tk.Entry(login_window, width=15, font="bold")
usernameEntry.place(x=150, y=26)

passwordEntry = tk.Entry(login_window, width=15, font="bold", show="*")
passwordEntry.place(x=150, y=66)

controlButton = tk.Button(login_window, text="LOGIN", width=30, font="bold", command=login)
controlButton.place(x=10, y=150)

login_window.mainloop()
